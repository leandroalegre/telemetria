export const environment = {
  production: true,
  API_URL:'https://apipruebasistema.modernizacionvcp.gob.ar'
};
