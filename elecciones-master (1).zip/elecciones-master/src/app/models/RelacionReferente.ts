export interface Relacion_referente {
  id_relacion_referente?: number;
  id_persona?: number | string;
  id_persona_referente ?: number | string;
}
