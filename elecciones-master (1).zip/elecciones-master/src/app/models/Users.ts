export interface Users{
  id?: number;
  id_persona?: number;
  password?: string;
  role?: string;
  refreshToken?: string;
}
