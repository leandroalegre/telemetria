export interface Personas{
  id_persona?: number;
  nombre_completo?: string;
  genero?: string;
  dni?: string;
  tipo_dni?: string;
  direccion?: string;
  barrio?: string;
  oposicion?: number;
}
