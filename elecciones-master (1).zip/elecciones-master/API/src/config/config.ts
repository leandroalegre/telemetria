export default {
    jwtSecret: 'BDPEK@',
    jwtSecretRefresh: 'WHM@1234'
  };
  